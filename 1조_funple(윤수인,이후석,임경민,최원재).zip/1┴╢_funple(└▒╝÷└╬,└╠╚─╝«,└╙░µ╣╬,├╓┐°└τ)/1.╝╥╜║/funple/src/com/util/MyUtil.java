package com.util;

//pageó�� Ŭ����
public class MyUtil {

	//��ü �������� ����
	public int getPageCount(int numPerPage,int dataCount) {

		int pageCount = 0;

		pageCount = dataCount / numPerPage;

		if(dataCount % numPerPage != 0) {
			pageCount++;
		}

		return pageCount;

	}

	//����¡ ó�� �޼ҵ�

	public String pageIndexList(int currentPage, int totalPage,
			String listUrl) {

		int numPerBlock = 5;//ǥ���ϴ� ������ ����
		int currentPageSetup;
		int page;

		StringBuffer sb = new StringBuffer();

		if(currentPage==0 || totalPage==0) {
			return "";
		}
		//list.jsp
		//list.jsp?searchKdy=name&searchValue=suzi
		if(listUrl.indexOf("?")!=-1) {
			listUrl = listUrl + "&";		
		}else {
			listUrl = listUrl + "?";
		}
		
		currentPageSetup = (currentPage/numPerBlock)*numPerBlock;
		
		if(currentPage % numPerBlock == 0) {
			currentPageSetup = currentPageSetup - numPerBlock;
		}
		
		//������
		if(totalPage > numPerBlock && currentPageSetup > 0) {
			
			sb.append("<a href=\"" + listUrl + "pageNum="
					+ currentPageSetup + "\">������</a>&nbsp;");
			
		}
		
		//�ٷΰ��� ������
		
		page = currentPageSetup +1;
		
		while(page <= totalPage && page <= (currentPageSetup + numPerBlock)) {
			
			if(page == currentPage) {
				
				sb.append("<font color=\"Fuchsia\">" + page + "</font>&nbsp;");
				//<font color="Fuchsia">9</font>&nbsp;
			}else {
				
				sb.append("<a href=\"" + listUrl + "pageNum=" +
				page + "\">" + page + "</a>&nbsp;");
				
			}
			page++;
		}
		
		//������ �����
		
		if(totalPage-currentPageSetup>numPerBlock) {
			sb.append("<a href=\"" + listUrl + "pageNum="+page+"\">������</a&nbsp;");
			
		}
		return sb.toString();

	}
}
