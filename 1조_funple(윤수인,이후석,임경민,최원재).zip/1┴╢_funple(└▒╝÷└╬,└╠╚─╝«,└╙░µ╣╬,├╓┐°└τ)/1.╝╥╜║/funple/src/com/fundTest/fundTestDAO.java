package com.fundTest;

//�ļ��̲�!!!!!

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class fundTestDAO {
	
	private Connection conn = null;
	
	public fundTestDAO(Connection conn) {
		this.conn = conn;
	}
	
//--------------getNum----------------------------------------
	
	public int getMaxNumProduct() {
		
		int maxNum = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select nvl(max(pnum),0) from product";
			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				maxNum = rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return maxNum;
	}
	
	public int getMaxNumMyorder() {
		
		int maxNum = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select nvl(max(onum),0) from myorder";
			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				maxNum = rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return maxNum;
	}
	
	public int getMaxNumMysale() {
		
		int maxNum = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select nvl(max(snum),0) from mysale";
			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				maxNum = rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return maxNum;
	}
	
	public int getListMycartNumDouble(int doublepnum,String cid) {
		
		int maxNum = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select nvl(count(pnum),0) from (select * from mycart where PNUM = ? and cid = ?)";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, doublepnum);
			pstmt.setString(2, cid);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				maxNum = rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return maxNum;
	}
	
//--------------getNum----------------------------------------
	

//--------------getCustomData-----------------------------------
		
	public fundTestDTO getCustomData(String cid) {
		
		fundTestDTO dto = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select cid,cpwd,cname,cemail,cbirth,ctel,cphone,caccount,ccard,caddress ";
			sql += "from customer where cid=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, cid);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new fundTestDTO();
				
				dto.setCid(rs.getString("cid"));
				dto.setCpwd(rs.getString("cpwd"));
				dto.setCname(rs.getString("cname"));
				dto.setCemail(rs.getString("cemail"));
				dto.setCbirth(rs.getString("cbirth"));
				dto.setCtel(rs.getString("ctel"));
				dto.setCphone(rs.getString("cphone"));
				dto.setCaccount(rs.getString("caccount"));
				dto.setCcard(rs.getString("ccard"));
				dto.setCaddress(rs.getString("caddress"));
				
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {

			System.out.println(e.toString());
			
		}
		
		return dto;
		
	}
	
//--------------getCustomData-----------------------------------


//--------------insert----------------------------------
//20240127

public int insertCustomer(fundTestDTO dto) {
	
	int result = 0;
	PreparedStatement pstmt = null;
	String sql;
	
	try {
		
		sql = "insert into customer (cid,cpwd,cname,cemail,cbirth,ctel,cphone,caccount,ccard,caddress) ";
		sql += "values (?,?,?,?,?,?,?,?,?,?)";
		
		pstmt = conn.prepareStatement(sql);
		
		pstmt.setString(1, dto.getCid());
		pstmt.setString(2, dto.getCpwd());
		pstmt.setString(3, dto.getCname());
		pstmt.setString(4, dto.getCemail());
		pstmt.setString(5, dto.getCbirth());
		pstmt.setString(6, dto.getCtel());
		pstmt.setString(7, dto.getCphone());
		pstmt.setString(8, dto.getCaccount());
		pstmt.setString(9, dto.getCcard());
		pstmt.setString(10, dto.getCaddress());
		
		result = pstmt.executeUpdate();
		
		pstmt.close();
		
	} catch (Exception e) {
		
		System.out.println(e.toString());
		
	}
	
	return result;
	
}

//------------------------------------------------

	public int insertProduct(fundTestDTO dto) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "insert into product (pnum,ptype,pproname,pimage1,pimage2,pimage3,pimage4,";
			sql+= "pstart,pend,ptag1,ptag2,ptag3,pgoal,ppeople,pcount,pprice,pdetail,psalesum) ";
			sql+= "values (?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,?,0)";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, getMaxNumProduct() + 1);
			pstmt.setString(2, dto.getPtype());
			pstmt.setString(3, dto.getPproname());
			pstmt.setString(4, dto.getPimage1());
			pstmt.setString(5, dto.getPimage2());
			pstmt.setString(6, dto.getPimage3());
			pstmt.setString(7, dto.getPimage4());
			pstmt.setString(8, dto.getPstart());
			pstmt.setString(9, dto.getPend());
			pstmt.setString(10, dto.getPtag1());
			pstmt.setString(11, dto.getPtag2());
			pstmt.setString(12, dto.getPtag3());
			pstmt.setInt(13, dto.getPgoal());
			pstmt.setInt(14, dto.getPcount());
			pstmt.setInt(15, dto.getPprice());
			pstmt.setString(16, dto.getPdetail());

			
			result = pstmt.executeUpdate();
			
			pstmt.close();
		
		} catch (Exception e) {
			
			System.out.println(e.toString());
			
		}
		
		return result;
		
	}
	
//------------------------------------------------

	public int insertMyorder(fundTestDTO dto) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "insert into myorder (onum,cid,pproname,pimage1,oamount,caddress,pprice,pnum,odelivery)"; 
			sql+= "values (?,?,?,?,?,?,?,?,3000)";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, getMaxNumMyorder() + 1);
			pstmt.setString(2, dto.getCid());
			pstmt.setString(3, dto.getPproname());
			pstmt.setString(4, dto.getPimage1());
			pstmt.setInt(5, dto.getOamount());
			pstmt.setString(6, dto.getCaddress());
			pstmt.setInt(7, dto.getPprice());
			pstmt.setInt(8, dto.getPnum());

			result = pstmt.executeUpdate();
			
			pstmt.close();
		
		} catch (Exception e) {
			
			System.out.println(e.toString());
			
		}
		
		return result;
		
	}

//------------------------------------------------
	
	public int insertMysale(fundTestDTO dto) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "insert into mysale (snum,cid,pproname,pimage1,pcount,psalesum,pprice,pnum)"; 
			sql+= "values (?,?,?,?,?,?,?,?)";
			
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, getMaxNumMysale() + 1);
			pstmt.setString(2, dto.getCid());
			pstmt.setString(3, dto.getPproname());
			pstmt.setString(4, dto.getPimage1());
			pstmt.setInt(5, dto.getPcount());
			pstmt.setInt(6, dto.getPsalesum());
			pstmt.setInt(7, dto.getPprice());
			pstmt.setInt(8, dto.getPnum());

			
			result = pstmt.executeUpdate();
			
			pstmt.close();
		
		} catch (Exception e) {
			
			System.out.println(e.toString());
			
		}
		
		return result;
		
	}
	
//------------------------------------------------

	public int insertMycart(fundTestDTO dto) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "insert into mycart (pnum,cid,pproname,pprice,pimage1,oamount)"; 
			sql+= "values (?,?,?,?,?,?)";
			
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, dto.getPnum());
			pstmt.setString(2, dto.getCid());
			pstmt.setString(3, dto.getPproname());
			pstmt.setInt(4, dto.getPprice());
			pstmt.setString(5, dto.getPimage1());
			pstmt.setInt(6, dto.getOamount());


			
			result = pstmt.executeUpdate();
			
			pstmt.close();
		
		} catch (Exception e) {
			
			System.out.println(e.toString());
			
		}
		
		return result;
		
	}
	
	
//--------------insert------------------------------------
	

//--------------getList---------------------------------------
	
	public List<fundTestDTO> getListProduct(int start, int end,String searchValue){
		
		List<fundTestDTO> lists = new ArrayList<fundTestDTO>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			searchValue = "%" + searchValue + "%";
			
			sql = "select * from ( ";
			sql+= "select rownum rnum, data.* from ( ";
			
			sql+= "select pnum,ptype,pproname,pimage1,pimage2,pimage3,pimage4, ";
			sql+= "pstart,pend,ptag1,ptag2,ptag3,pgoal,ppeople,pcount,pprice,pdetail,psalesum ";	
			sql+= "from product where PTYPE LIKE ? OR pproname LIKE ? OR PTAG1 LIKE ? OR PTAG2 LIKE ? OR PTAG3 LIKE ? ORDER BY pnum DESC ";
						
			sql+= ")data) where rnum>=? and rnum<=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, searchValue);
			pstmt.setString(2, searchValue);
			pstmt.setString(3, searchValue);
			pstmt.setString(4, searchValue);
			pstmt.setString(5, searchValue);
			pstmt.setInt(6, start);
			pstmt.setInt(7, end);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
			fundTestDTO dto = new fundTestDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setPtype(rs.getString("ptype"));
				dto.setPproname(rs.getString("pproname"));
				dto.setPimage1(rs.getString("pimage1"));
				dto.setPimage2(rs.getString("pimage2"));
				dto.setPimage3(rs.getString("pimage3"));
				dto.setPimage4(rs.getString("pimage4"));
				dto.setPstart(rs.getString("pstart"));
				dto.setPend(rs.getString("pend"));
				dto.setPtag1(rs.getString("ptag1"));
				dto.setPtag2(rs.getString("ptag2"));
				dto.setPtag3(rs.getString("ptag3"));
				dto.setPgoal(rs.getInt("pgoal"));
				dto.setPpeople(rs.getInt("ppeople"));
				dto.setPcount(rs.getInt("pcount"));
				dto.setPprice(rs.getInt("pprice"));
				dto.setPdetail(rs.getString("pdetail"));
				dto.setPsalesum(rs.getInt("psalesum"));
				
				dto.setRownum(rs.getInt("rnum"));
				
				lists.add(dto);
				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}

//-----------------------------------------------------
	
public List<fundTestDTO> getListMyorder(String cid){
		
		List<fundTestDTO> lists = new ArrayList<fundTestDTO>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select * from ( ";
			sql+= "select rownum rnum, data.* from ( ";
			
			sql+= "select onum,cid,pproname,pimage1,oamount,caddress,pprice,pnum,odelivery ";
			
			sql+= "from myorder where cid=? order by onum desc) data) ";

			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cid);

			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				fundTestDTO dto = new fundTestDTO();
				
				dto.setOnum(rs.getInt("onum"));
				dto.setCid(rs.getString("cid"));
				dto.setPproname(rs.getString("pproname"));
				dto.setPimage1(rs.getString("pimage1"));
				dto.setOamount(rs.getInt("oamount"));
				dto.setCaddress(rs.getString("caddress"));
				dto.setPprice(rs.getInt("pprice"));
				dto.setPnum(rs.getInt("pnum"));
				dto.setOdelivery(rs.getInt("odelivery"));
				
				dto.setRownum(rs.getInt("rnum"));
				
				lists.add(dto);
				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}
	
//-----------------------------------------------------��


public List<fundTestDTO> getListBestProduct(int start, int end, String searchValue) {

	List<fundTestDTO> lists = new ArrayList<fundTestDTO>();

	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql;

	try {

		searchValue = "%" + searchValue + "%";

		sql = "select * from ( ";
		sql += "select rownum rnum, data.* from ( ";

		sql += "select pnum,ptype,pproname,pimage1,pimage2,pimage3,pimage4, ";
		sql += "pstart,pend,ptag1,ptag2,ptag3,pgoal,ppeople,pcount,pprice,pdetail,psalesum ";
		sql += "from product where PTYPE LIKE ? OR pproname LIKE ? OR PTAG1 LIKE ? OR PTAG2 LIKE ? OR PTAG3 LIKE ? ORDER BY ppeople DESC ";

		sql += ")data) where rnum>=? and rnum<=?";

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, searchValue);
		pstmt.setString(2, searchValue);
		pstmt.setString(3, searchValue);
		pstmt.setString(4, searchValue);
		pstmt.setString(5, searchValue);
		pstmt.setInt(6, start);
		pstmt.setInt(7, end);

		rs = pstmt.executeQuery();

		while (rs.next()) {

			fundTestDTO dto = new fundTestDTO();

			dto.setPnum(rs.getInt("pnum"));
			dto.setPtype(rs.getString("ptype"));
			dto.setPproname(rs.getString("pproname"));
			dto.setPimage1(rs.getString("pimage1"));
			dto.setPimage2(rs.getString("pimage2"));
			dto.setPimage3(rs.getString("pimage3"));
			dto.setPimage4(rs.getString("pimage4"));
			dto.setPstart(rs.getString("pstart"));
			dto.setPend(rs.getString("pend"));
			dto.setPtag1(rs.getString("ptag1"));
			dto.setPtag2(rs.getString("ptag2"));
			dto.setPtag3(rs.getString("ptag3"));
			dto.setPgoal(rs.getInt("pgoal"));
			dto.setPpeople(rs.getInt("ppeople"));
			dto.setPcount(rs.getInt("pcount"));
			dto.setPprice(rs.getInt("pprice"));
			dto.setPdetail(rs.getString("pdetail"));
			dto.setPsalesum(rs.getInt("psalesum"));

			dto.setRownum(rs.getInt("rnum"));

			lists.add(dto);

		}
		rs.close();
		pstmt.close();

	} catch (Exception e) {
		System.out.println(e.toString());
	}
	return lists;
}




	public List<fundTestDTO> getListMysale(int start, int end,String cid){
		
		List<fundTestDTO> lists = new ArrayList<fundTestDTO>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select * from ( ";
			sql+= "select rownum rnum, data.* from ( ";
			
			sql+= "select snum,cid,pproname,PIMAGE1,PCOUNT,psalesum,pprice,pnum ";
			
			sql+= "from mysale order by snum desc) data) ";
			sql+= "where rnum>=? and rnum<=? and cid=?";
			//���⺸����
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			pstmt.setString(3, cid);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				fundTestDTO dto = new fundTestDTO();
				
				dto.setSnum(rs.getInt("snum"));
				dto.setCid(rs.getString("cid"));
				dto.setPproname(rs.getString("pproname"));
				dto.setPimage1(rs.getString("pimage1"));
				dto.setPcount(rs.getInt("pcount"));
				dto.setPsalesum(rs.getInt("psalesum"));
				dto.setPprice(rs.getInt("pprice"));
				dto.setPnum(rs.getInt("pnum"));
				
				dto.setRownum(rs.getInt("rnum"));
				
				lists.add(dto);

			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}
	
//-----------------------------------------------------

	public List<fundTestDTO> getListMycartNum(String cid){
		
		List<fundTestDTO> lists = new ArrayList<fundTestDTO>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select * from ( ";
			sql+= "select rownum rnum, data.* from ( ";
			sql+= "select pnum,cid,pproname,pimage1,oamount,pprice ";
			sql+= "from mycart order by pnum desc) data ";
			sql+= "where cid=?)";
			
			
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cid);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				fundTestDTO dtto = new fundTestDTO();
				
				dtto.setRownum(rs.getInt("rnum"));
				
				lists.add(dtto);
				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}
	
	public List<fundTestDTO> getListMycart1(int start, int end,String cid){
		
		List<fundTestDTO> lists = new ArrayList<fundTestDTO>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			

			sql = "select * from( ";
			sql+= "select rownum rnum, data.* from ( ";
			sql+= "select pnum,cid,pproname,pimage1,oamount,pprice ";
			sql+= "from mycart order by pnum desc) data ";
			sql+= "where cid=?)where rnum>=? and rnum<=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cid);
			pstmt.setInt(2, start);
			pstmt.setInt(3, end);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				fundTestDTO dto = new fundTestDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setCid(rs.getString("cid"));
				dto.setPproname(rs.getString("pproname"));
				dto.setPimage1(rs.getString("pimage1"));
				dto.setOamount(rs.getInt("oamount"));
				dto.setPprice(rs.getInt("pprice"));
				
				dto.setRownum(rs.getInt("rnum"));
				
				lists.add(dto);
				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}
	
	public List<fundTestDTO> getListMycart2(int start, int end,String cid){
		
		List<fundTestDTO> lists = new ArrayList<fundTestDTO>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select * from( ";
			sql+= "select rownum rnum, data.* from ( ";
			sql+= "select pnum,cid,pproname,pimage1,oamount,pprice ";
			sql+= "from mycart order by pnum desc) data ";
			sql+= "where cid=?)where rnum>=? and rnum<=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cid);
			pstmt.setInt(2, start);
			pstmt.setInt(3, end);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				fundTestDTO dto = new fundTestDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setCid(rs.getString("cid"));
				dto.setPproname(rs.getString("pproname"));
				dto.setPimage1(rs.getString("pimage1"));
				dto.setOamount(rs.getInt("oamount"));
				dto.setPprice(rs.getInt("pprice"));
				
				dto.setRownum(rs.getInt("rnum"));
				
				lists.add(dto);
				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}
	
	public List<fundTestDTO> getListMycart3(int start, int end,String cid){
		
		List<fundTestDTO> lists = new ArrayList<fundTestDTO>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select * from( ";
			sql+= "select rownum rnum, data.* from ( ";
			sql+= "select pnum,cid,pproname,pimage1,oamount,pprice ";
			sql+= "from mycart order by pnum desc) data ";
			sql+= "where cid=?)where rnum>=? and rnum<=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cid);
			pstmt.setInt(2, start);
			pstmt.setInt(3, end);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				fundTestDTO dto = new fundTestDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setCid(rs.getString("cid"));
				dto.setPproname(rs.getString("pproname"));
				dto.setPimage1(rs.getString("pimage1"));
				dto.setOamount(rs.getInt("oamount"));
				dto.setPprice(rs.getInt("pprice"));
				
				dto.setRownum(rs.getInt("rnum"));
				
				lists.add(dto);
				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}
	
	public List<fundTestDTO> getListMycart4(int start, int end,String cid){
		
		List<fundTestDTO> lists = new ArrayList<fundTestDTO>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select * from( ";
			sql+= "select rownum rnum, data.* from ( ";
			sql+= "select pnum,cid,pproname,pimage1,oamount,pprice ";
			sql+= "from mycart order by pnum desc) data ";
			sql+= "where cid=?)where rnum>=? and rnum<=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cid);
			pstmt.setInt(2, start);
			pstmt.setInt(3, end);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				fundTestDTO dto = new fundTestDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setCid(rs.getString("cid"));
				dto.setPproname(rs.getString("pproname"));
				dto.setPimage1(rs.getString("pimage1"));
				dto.setOamount(rs.getInt("oamount"));
				dto.setPprice(rs.getInt("pprice"));
				
				dto.setRownum(rs.getInt("rnum"));
				
				lists.add(dto);
				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}
	
	public List<fundTestDTO> getListMycart5(int start, int end,String cid){
		
		List<fundTestDTO> lists = new ArrayList<fundTestDTO>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select * from( ";
			sql+= "select rownum rnum, data.* from ( ";
			sql+= "select pnum,cid,pproname,pimage1,oamount,pprice ";
			sql+= "from mycart order by pnum desc) data ";
			sql+= "where cid=?)where rnum>=? and rnum<=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cid);
			pstmt.setInt(2, start);
			pstmt.setInt(3, end);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				fundTestDTO dto = new fundTestDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setCid(rs.getString("cid"));
				dto.setPproname(rs.getString("pproname"));
				dto.setPimage1(rs.getString("pimage1"));
				dto.setOamount(rs.getInt("oamount"));
				dto.setPprice(rs.getInt("pprice"));
				
				dto.setRownum(rs.getInt("rnum"));
				
				lists.add(dto);
				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return lists;
	}
	
	
	
	
//--------------getList---------------------------------------
	
	
//--------------getDataCount---------------------------------------
	public int getDataCountProduct(String searchValue) {
		
		int dataCount = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			searchValue = "%" + searchValue + "%";
			
			sql = "select nvl(count(*),0) from(select * from product where PTYPE LIKE ? OR pproname LIKE ? OR PTAG1 LIKE ? OR PTAG2 LIKE ? OR PTAG3 LIKE ? ORDER BY pnum DESC)";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, searchValue);
			pstmt.setString(2, searchValue);
			pstmt.setString(3, searchValue);
			pstmt.setString(4, searchValue);
			pstmt.setString(5, searchValue);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dataCount = rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return dataCount;
	}
	
	public int getDataCountOrderID(int pnum) {
		
		int dataCount = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select nvl(count(*),0) from myorder where PNUM = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, pnum);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dataCount = rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return dataCount;
	}
	
//--------------getData---------------------------------------
	
	public int getDataCountMyorder() {
		
		int dataCount = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select nvl(count(*),0) from myorder";
			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dataCount = rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return dataCount;
	}
	
//---------------------------------------------------
	
	public int getDataCountMysale() {
		
		int dataCount = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select nvl(count(*),0) from mysale";
			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dataCount = rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return dataCount;
	}
	
//---------------------------------------------------
	
	public int getDataCountMycart() {
		
		int dataCount = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select nvl(count(*),0) from mycart";
			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dataCount = rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return dataCount;
	}
	
//--------------getDataCount---------------------------------------
	
//--------------getReadData---------------------------------------



//-----------------------------------------------------
	
	public fundTestDTO getReadDataProduct(int pnum){
		
		fundTestDTO dto = null;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select pnum,ptype,pproname,pimage1,pimage2,pimage3,pimage4, ";
			sql+= "TO_CHAR(pstart, 'YYYY-MM-DD') as pstart,TO_CHAR(pend, 'YYYY-MM-DD') as pend,ptag1,ptag2,ptag3,pgoal,ppeople,pcount,pprice,pdetail,psalesum ";

			sql+= "from product where pnum=?";

			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, pnum);

			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new fundTestDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setPtype(rs.getString("ptype"));
				dto.setPproname(rs.getString("pproname"));
				dto.setPimage1(rs.getString("pimage1"));
				dto.setPimage2(rs.getString("pimage2"));
				dto.setPimage3(rs.getString("pimage3"));
				dto.setPimage4(rs.getString("pimage4"));
				dto.setPstart(rs.getString("pstart"));
				dto.setPend(rs.getString("pend"));
				dto.setPtag1(rs.getString("ptag1"));
				dto.setPtag2(rs.getString("ptag2"));
				dto.setPtag3(rs.getString("ptag3"));
				dto.setPgoal(rs.getInt("pgoal"));
				dto.setPpeople(rs.getInt("ppeople"));
				dto.setPcount(rs.getInt("pcount"));
				dto.setPprice(rs.getInt("pprice"));
				dto.setPdetail(rs.getString("pdetail"));
				dto.setPsalesum(rs.getInt("psalesum"));
				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return dto;
	}

//-----------------------------------------------------
	
	public fundTestDTO getReadDataMyorder(int onum){
		
		fundTestDTO dto = null;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select onum,cid,pproname,pimage1,oamount,caddress,pprice,pnum,odelivery ";
			
			sql+= "from myorder where pnum=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, onum);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new fundTestDTO();
				
				dto.setOnum(rs.getInt("onum"));
				dto.setCid(rs.getString("cid"));
				dto.setPproname(rs.getString("pproname"));
				dto.setPimage1(rs.getString("pimage1"));
				dto.setOamount(rs.getInt("oamount"));
				dto.setCaddress(rs.getString("caddress"));
				dto.setPprice(rs.getInt("pprice"));
				dto.setPnum(rs.getInt("pnum"));
				dto.setOdelivery(rs.getInt("odelivery"));
				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return dto;
	}

//-----------------------------------------------------
	
	public fundTestDTO getReadDataMysale(int snum){
		
		fundTestDTO dto = null;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select snum,cid,pproname,pimage1,psalesum,pprice,pnum ";
			
			sql+= "from mysale where pnum=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, snum);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new fundTestDTO();
				
				dto.setSnum(rs.getInt("snum"));
				dto.setCid(rs.getString("cid"));
				dto.setPproname(rs.getString("pproname"));
				dto.setPimage1(rs.getString("pimage1"));
				dto.setPsalesum(rs.getInt("psalesum"));
				dto.setPprice(rs.getInt("pprice"));
				dto.setPnum(rs.getInt("pnum"));

				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return dto;
	}
	
//-----------------------------------------------------
	
	public fundTestDTO getReadDataMycart(int pnum){
		
		fundTestDTO dto = null;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select pnum,cid,pproname,oamount,pprice ";
			
			sql+= "from mycart where pnum=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, pnum);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new fundTestDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setCid(rs.getString("cid"));
				dto.setPproname(rs.getString("pproname"));
				dto.setOamount(rs.getInt("oamount"));
				dto.setPprice(rs.getInt("pprice"));

				
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return dto;
	}

//--------------getReadData---------------------------------------


//-------------- searchCustomData----------------------------------
	
	public fundTestDTO searchCustomData(String cname,String ctel, String cphone) {
		
		fundTestDTO dto = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select cid,cpwd,cname,cemail,cbirth,ctel,cphone,caccount,ccard,caddress ";
			sql += "from customer where cname=? and ctel=? and cphone=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, cname);
			pstmt.setString(2, ctel);
			pstmt.setString(3, cphone);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new fundTestDTO();
				
				dto.setCid(rs.getString("cid"));
				dto.setCpwd(rs.getString("cpwd"));
				dto.setCname(rs.getString("cname"));
				dto.setCemail(rs.getString("cemail"));
				dto.setCbirth(rs.getString("cbirth"));
				dto.setCtel(rs.getString("ctel"));
				dto.setCphone(rs.getString("cphone"));
				dto.setCaccount(rs.getString("caccount"));
				dto.setCcard(rs.getString("ccard"));
				dto.setCaddress(rs.getString("caddress"));
				
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {

			System.out.println(e.toString());
			
		}
		
		return dto;
		
	}

//-------------- searchCustomPassword(---------------------------------

public fundTestDTO searchCustomPassword(String cid,String cname,String ctel, String cphone) {
	
	fundTestDTO dto = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql;
	
	try {
		
		sql = "select cid,cpwd,cname,cemail,cbirth,ctel,cphone,caccount,ccard,caddress ";
		sql += "from customer where cid=? and cname=? and ctel=? and cphone=?";
		
		pstmt = conn.prepareStatement(sql);
		
		pstmt.setString(1, cid);
		pstmt.setString(2, cname);
		pstmt.setString(3, ctel);
		pstmt.setString(4, cphone);
		
		rs = pstmt.executeQuery();
		
		if(rs.next()) {
			
			dto = new fundTestDTO();
			
			dto.setCid(rs.getString("cid"));
			dto.setCpwd(rs.getString("cpwd"));
			dto.setCname(rs.getString("cname"));
			dto.setCemail(rs.getString("cemail"));
			dto.setCbirth(rs.getString("cbirth"));
			dto.setCtel(rs.getString("ctel"));
			dto.setCphone(rs.getString("cphone"));
			dto.setCaccount(rs.getString("caccount"));
			dto.setCcard(rs.getString("ccard"));
			dto.setCaddress(rs.getString("caddress"));
			
		}
		
		rs.close();
		pstmt.close();
		
	} catch (Exception e) {

		System.out.println(e.toString());
		
	}
	
	return dto;
	
}

//-------------- searchCustomData----------------------------------

	
	
//--------------delete---------------------------------------
	
	public int deleteDataProduct(int pnum) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "delete product where pnum=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, pnum);
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return result;
	}
	
	public int deleteDataMyorder(int onum) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "delete myorder where onum=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, onum);
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return result;
	}
	
	public int deleteDataMysale(int snum) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "delete mysale where snum=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, snum);
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return result;
	}
	
	public int deleteDataMycart(int pnum) {//��ǰ �ϳ� ����°���
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "delete mycart where pnum=?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, pnum);
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return result;
	}
	
//--------------delete---------------------------------------
	
//--------------update--------------------------------------
		
	public int updateData(fundTestDTO dto) {

		int result = 0;

		PreparedStatement pstmt = null;
		String sql;

		try {

		    sql = "UPDATE customer SET cpwd=?, cemail=?, ctel=?, cphone=?, caccount=?, ccard=?, caddress=?"; 
		    sql += "WHERE cid=?";
			
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, dto.getCpwd());
			pstmt.setString(2, dto.getCemail());
			pstmt.setString(3, dto.getCtel());
			pstmt.setString(4, dto.getCphone());
			pstmt.setString(5, dto.getCaccount());
			pstmt.setString(6, dto.getCcard());
			pstmt.setString(7, dto.getCaddress());
			pstmt.setString(8, dto.getCid());

			result = pstmt.executeUpdate();
			
			pstmt.close();

		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return result;
	}
	
	public int updateProduct(fundTestDTO dto) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "UPDATE product SET ppeople = ?, psalesum = ? WHERE pnum = ?";
			
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, getDataCountOrderID(dto.getPnum()));//getlistordercount
			pstmt.setInt(2, getProductpSalesum(dto.getPnum()) + dto.getOamount());//omount��ŭ ����
			pstmt.setInt(3, dto.getPnum());

			
			result = pstmt.executeUpdate();
			
			pstmt.close();
		
		} catch (Exception e) {
			
			System.out.println(e.toString());
			
		}
		
		return result;
		
	}
	
	public int updateMysale(fundTestDTO dto) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			sql = "UPDATE mysale SET psalesum = ? WHERE pnum = ?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, getMysaleSalesum(dto.getPnum()) + dto.getOamount());//omount��ŭ ����
			pstmt.setInt(2, dto.getPnum());
			
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			
		} catch (Exception e) {
			
			System.out.println(e.toString());
			
		}
		
		return result;
		
	}
	
//--------------update--------------------------------------

	
	public int getProductpSalesum(int pnum) {
		
		int salesum = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select PSALESUM from product where pnum = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, pnum);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				salesum = rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return salesum;
	}
	
	public int getMysaleSalesum(int pnum) {
		
		int salesum = 0;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			
			sql = "select PSALESUM from mysale where pnum = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, pnum);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				salesum = rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return salesum;
	}
	
}
