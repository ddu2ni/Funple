package com.fundTest;

public class fundTestDTO {
	
//	��ǰ����(product ����)
	private int pnum;
	private String ptype;
	private String pproname;
	private String pimage1;
	private String pimage2;
	private String pimage3;
	private String pimage4;
	private String pstart;
	private String pend;
	private String ptag1;
	private String ptag2;
	private String ptag3;
	private int pgoal;
	private int ppeople;
	private int pcount;
	private int pprice;
	private String pdetail;
	private int psalesum;
//	��ǰ����(product ����)
	
//	ȸ������(customer ����)
	private String cid;
	private String cpwd;
	private String cname;
	private String cemail;
	private String cbirth;
	private String ctel;
	private String cphone;
	private String caccount;
	private String ccard;
	private String caddress;
//	ȸ������(customer ����)
	
//	�ֹ�����(myorder ����)
	private int onum;
	private int oamount;
	private int odelivery;
//	�ֹ�����(myorder ����)
	
//	�Ǹų���(mysale ����)
	private int snum;
//	�Ǹų���(mysale ����)
	
	private int rownum;
	
	public String getCpwd() {
		return cpwd;
	}
	public void setCpwd(String cpwd) {
		this.cpwd = cpwd;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCemail() {
		return cemail;
	}
	public void setCemail(String cemail) {
		this.cemail = cemail;
	}
	public String getCbirth() {
		return cbirth;
	}
	public void setCbirth(String cbirth) {
		this.cbirth = cbirth;
	}
	public String getCtel() {
		return ctel;
	}
	public void setCtel(String ctel) {
		this.ctel = ctel;
	}
	public String getCphone() {
		return cphone;
	}
	public void setCphone(String cphone) {
		this.cphone = cphone;
	}
	public String getCaccount() {
		return caccount;
	}
	public void setCaccount(String caccount) {
		this.caccount = caccount;
	}
	public String getCcard() {
		return ccard;
	}
	public void setCcard(String ccard) {
		this.ccard = ccard;
	}
	public String getCaddress() {
		return caddress;
	}
	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	
	public int getPpeople() {
		return ppeople;
	}
	public void setPpeople(int ppeople) {
		this.ppeople = ppeople;
	}
	public int getPsalesum() {
		return psalesum;
	}
	public void setPsalesum(int psalesum) {
		this.psalesum = psalesum;
	}
	public int getRownum() {
		return rownum;
	}
	public void setRownum(int rownum) {
		this.rownum = rownum;
	}
	public int getOnum() {
		return onum;
	}
	public void setOnum(int onum) {
		this.onum = onum;
	}
	public int getOamount() {
		return oamount;
	}
	public void setOamount(int oamount) {
		this.oamount = oamount;
	}
	public int getOdelivery() {
		return odelivery;
	}
	public void setOdelivery(int odelivery) {
		this.odelivery = odelivery;
	}
	public int getSnum() {
		return snum;
	}
	public void setSnum(int snum) {
		this.snum = snum;
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public String getPtype() {
		return ptype;
	}
	public void setPtype(String ptype) {
		this.ptype = ptype;
	}
	public String getPproname() {
		return pproname;
	}
	public void setPproname(String pproname) {
		this.pproname = pproname;
	}
	public String getPimage1() {
		return pimage1;
	}
	public void setPimage1(String pimage1) {
		this.pimage1 = pimage1;
	}
	public String getPimage2() {
		return pimage2;
	}
	public void setPimage2(String pimage2) {
		this.pimage2 = pimage2;
	}
	public String getPimage3() {
		return pimage3;
	}
	public void setPimage3(String pimage3) {
		this.pimage3 = pimage3;
	}
	public String getPimage4() {
		return pimage4;
	}
	public void setPimage4(String pimage4) {
		this.pimage4 = pimage4;
	}
	public String getPstart() {
		return pstart;
	}
	public void setPstart(String pstart) {
		this.pstart = pstart;
	}
	public String getPend() {
		return pend;
	}
	public void setPend(String pend) {
		this.pend = pend;
	}
	public String getPtag1() {
		return ptag1;
	}
	public void setPtag1(String ptag1) {
		this.ptag1 = ptag1;
	}
	public String getPtag2() {
		return ptag2;
	}
	public void setPtag2(String ptag2) {
		this.ptag2 = ptag2;
	}
	public String getPtag3() {
		return ptag3;
	}
	public int getPgoal() {
		return pgoal;
	}
	public void setPgoal(int pgoal) {
		this.pgoal = pgoal;
	}
	public int getPcount() {
		return pcount;
	}
	public void setPcount(int pcount) {
		this.pcount = pcount;
	}
	public int getPprice() {
		return pprice;
	}
	public void setPprice(int pprice) {
		this.pprice = pprice;
	}
	public void setPtag3(String ptag3) {
		this.ptag3 = ptag3;
	}
	public String getPdetail() {
		return pdetail;
	}
	public void setPdetail(String pdetail) {
		this.pdetail = pdetail;
	}
	
	
}
