package com.fundTest;


//�ļ��̲�!!!!!!
import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.util.DBConn;
import com.util.FileManager;
import com.util.MyUtil;


public class fundTestServlet extends HttpServlet{
	
private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req,resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req,resp);
	}
	
	protected void forward(HttpServletRequest req, HttpServletResponse resp ,String url) throws ServletException, IOException {
		RequestDispatcher rd = req.getRequestDispatcher(url);
		rd.forward(req, resp);
	}
	
	protected void process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.setCharacterEncoding("UTF-8");
		
		Connection conn = DBConn.getConnection();
		fundTestDAO dao = new fundTestDAO(conn);
		
		MyUtil myUtil = new MyUtil();
		
		String cp = req.getContextPath();
		String uri = req.getRequestURI();
		String url;
		
		String root = getServletContext().getRealPath("/");
		String path = root + "pds" + File.separator + "imageFile";
		
		File f = new File(path);
		if(!f.exists()) {
			f.mkdirs();
		}
		///
//---------------------------detail-----------------------------------

		
		if(uri.indexOf("detail.do")!=-1) {

			int num = Integer.parseInt(req.getParameter("num"));
			String pageNum = req.getParameter("pageNum");

			String searchValue = req.getParameter("searchValue");

			if(searchValue!=null) {
				searchValue = URLDecoder.decode(searchValue, "UTF-8");
			}


			fundTestDTO dto = dao.getReadDataProduct(num);

			if(dto==null) {
				url = cp + "/funple/list.do";
				resp.sendRedirect(url);
			}


			String param = "pageNum=" + pageNum;
			if(searchValue!=null && !searchValue.equals("")) {
				param += "&searchValue=" + URLDecoder.decode(searchValue, "UTF-8");
			}

			String imagePath = cp + "/pds/imageFile";
			req.setAttribute("imagePath", imagePath);
			req.setAttribute("dto", dto);
			req.setAttribute("params", param);
			req.setAttribute("pageNum", pageNum);

			url = "/fund/detail.jsp";
			forward(req, resp, url);
			}
			//----------------------------------
			else if(uri.indexOf("detail_ok.do")!=-1) {
				
				String cid = req.getParameter("cid");
				
				//���̵� ��������� �α����϶�� �ϼ�
				
				if(cid==null || cid.equals("")) {
					req.setAttribute("message", "�α����� �ʿ��մϴ�.");
					url = "/funple/login.do";
					forward(req, resp, url);
					return;
				}
				
				int doublepnum = Integer.parseInt(req.getParameter("pnum"));
				
				cid = URLDecoder.decode(cid,"UTF-8");
				
				int dttto = dao.getListMycartNumDouble(doublepnum,cid);
				
				if(dttto==1) {
					System.out.println(dttto);
					req.setAttribute("message", "�̹� ��� ��ǰ�Դϴ�.");
					url = "/funple/cart.do";
					forward(req, resp, url);
					return;
				}

				List<fundTestDTO> lists = dao.getListMycartNum(cid);
				
				for (fundTestDTO item : lists) {
					
				        if(item.getRownum()>=5) {
						req.setAttribute("message", "��ٱ��ϰ� ���� á���ϴ�.");
						url = "/funple/cart.do";
						forward(req, resp, url);
						return;
					}
			    }
				
				fundTestDTO dto = new fundTestDTO();
				
				dto.setPnum(Integer.parseInt(req.getParameter("pnum")));
				dto.setCid(cid);
				dto.setPproname(req.getParameter("pproname"));
				dto.setPprice(Integer.parseInt(req.getParameter("pprice")));
				dto.setPimage1(req.getParameter("pimage1"));
				dto.setOamount(Integer.parseInt(req.getParameter("oamount")));
				
				dao.insertMycart(dto);
						
				url = cp+ "/funple/cart.do";
				resp.sendRedirect(url);
			
		
		
//---------------------------detail-----------------------------------
		
		
//---------------------------list-----------------------------------

		
		}
		
		else if(uri.indexOf("list.do")!=-1) {
		
		String pageNum = req.getParameter("pageNum");
		
		int currentPage = 1;
		
		if(pageNum!=null) {
			currentPage = Integer.parseInt(pageNum);
		}
		
		String searchValue = req.getParameter("searchValue");
		
	
		if(searchValue!=null) {
			if(req.getMethod().equalsIgnoreCase("GET")) {
				searchValue = URLDecoder.decode(searchValue,"UTF-8");
				
			}
		} else {
			searchValue = "";
		}
		
		int dataCount = dao.getDataCountProduct(searchValue);
		
		int row = 4;
		int column = 2;
		int numPerPage = row * column;//x*y
		int totalPage = myUtil.getPageCount(numPerPage, dataCount);
		
		if(currentPage>totalPage) {
			currentPage = totalPage;
		}
		
		int start = (currentPage-1)*numPerPage+1;
		int end = currentPage*numPerPage;
		
		List<fundTestDTO> lists = dao.getListProduct(start,end,searchValue);
		
		String param = "";
		
		if(searchValue!=null && !searchValue.equals("")) {
			param = "&searchValue=" +
					URLDecoder.decode(searchValue,"UTF-8");
		}
		
		
		
		String urlList = cp + "/funple/list.do";
		
		if(!param.equals("")) {
			urlList += "?" + param;
		}

		String pageIndexList = myUtil.pageIndexList(currentPage, totalPage, urlList);
		
		String articleUrl = cp + "/funple/detail.do?pageNum=" + currentPage;
		
		if(!param.equals("")) {
			articleUrl += "&" + param;
		}
		
		String deletePath = cp + "/funple/delete.do";
		String downloadPath = cp + "/funple/download.do";
		
		String imagePath = cp + "/pds/imageFile";
		req.setAttribute("imagePath", imagePath);
		
		req.setAttribute("downloadPath", downloadPath);
		req.setAttribute("deletePath", deletePath);
		req.setAttribute("lists", lists);
		req.setAttribute("pageIndexList", pageIndexList);
		req.setAttribute("dataCount", dataCount);
		req.setAttribute("pageNum", currentPage);
		req.setAttribute("pageMax", totalPage);
		req.setAttribute("listsSize", lists.size());
		req.setAttribute("row", row);
		req.setAttribute("column", column);
		req.setAttribute("articleUrl", articleUrl);
		
		url = "/fund/list.jsp";
		
		forward(req, resp, url);
		
		}
		
	else if(uri.indexOf("bestsales.do")!=-1) {
		
		String pageNum = req.getParameter("pageNum");
		
		int currentPage = 1;
		
		if(pageNum!=null) {
			currentPage = Integer.parseInt(pageNum);
		}
		
		String searchValue = req.getParameter("searchValue");
		
//		if(searchValue==null) {
//			searchValue = "";
//		}else {
//			if(req.getMethod().equalsIgnoreCase("GET")) {
//				searchValue = URLDecoder.decode(searchValue, "UTF-8");
//			}
//		}
//		
		if(searchValue!=null) {
			if(req.getMethod().equalsIgnoreCase("GET")) {
				searchValue = URLDecoder.decode(searchValue,"UTF-8");
				
			}
		} else {
			searchValue = "";
		}
		
		int dataCount = dao.getDataCountProduct(searchValue);
		
		int row = 4;
		int column = 2;
		int numPerPage = row * column;//x*y
		int totalPage = myUtil.getPageCount(numPerPage, dataCount);
		
		if(currentPage>totalPage) {
			currentPage = totalPage;
		}
		
		int start = (currentPage-1)*numPerPage+1;
		int end = currentPage*numPerPage;
		
		List<fundTestDTO> lists = dao.getListBestProduct(start, end, searchValue);
		
		String param = "";
		
		if(searchValue!=null && !searchValue.equals("")) {
			param = "&searchValue=" +
					URLDecoder.decode(searchValue,"UTF-8");
		}
		
		
		String urlList = cp + "/funple/list.do";
		
		if(!param.equals("")) {
			urlList += "?" + param;
		}

		String pageIndexList = myUtil.pageIndexList(currentPage, totalPage, urlList);
		
		String articleUrl = cp + "/funple/detail.do?pageNum=" + currentPage;
		
		if(!param.equals("")) {
			articleUrl += "&" + param;
		}
		
		String deletePath = cp + "/funple/delete.do";
		String downloadPath = cp + "/funple/download.do";
		
		String imagePath = cp + "/pds/imageFile";
		req.setAttribute("imagePath", imagePath);
		
		req.setAttribute("downloadPath", downloadPath);
		req.setAttribute("deletePath", deletePath);
		req.setAttribute("lists", lists);
		req.setAttribute("pageIndexList", pageIndexList);
		req.setAttribute("dataCount", dataCount);
		req.setAttribute("pageNum", currentPage);
		req.setAttribute("pageMax", totalPage);
		req.setAttribute("listsSize", lists.size());
		req.setAttribute("row", row);
		req.setAttribute("column", column);
		req.setAttribute("articleUrl", articleUrl);
		
		url = "/fund/list.jsp";
		
		forward(req, resp, url);
		
//---------------------------list-----------------------------------
		
//---------------------------create-----------------------------------
		
	}else if(uri.indexOf("create.do")!=-1) {
			
		url = "/fund/create.jsp";
		forward(req, resp, url);
			
		}else if(uri.indexOf("create_ok.do")!=-1) {
			
			//���Ͼ��ε�
			String encType = "UTF-8";
			int maxSize = 10 * 1024 * 1024;
			
			MultipartRequest mr = new MultipartRequest(req, path, maxSize, encType,
									new DefaultFileRenamePolicy());
			
			HttpSession session = req.getSession();
			
			//�������� DB�� ����
			if(mr.getFile("pimage1")!=null || 
					mr.getFile("pimage2")!=null ||
					mr.getFile("pimage3")!=null ||
					mr.getFile("pimage4")!=null ||
					mr.getFile("pdetail")!=null) {
				
				int maxNum = dao.getMaxNumProduct();
				int maxsNum = dao.getMaxNumMysale();

				fundTestDTO dto = new fundTestDTO();
				
				String cid =(String)session.getAttribute("cid");
				
				dto.setPnum(maxNum + 1);
				dto.setPtype(mr.getParameter("ptype"));
				dto.setPproname(mr.getParameter("pproname"));
				dto.setPimage1(mr.getFilesystemName("pimage1"));
				dto.setPimage2(mr.getFilesystemName("pimage2"));
				dto.setPimage3(mr.getFilesystemName("pimage3"));
				dto.setPimage4(mr.getFilesystemName("pimage4"));
				dto.setPstart(mr.getParameter("pstart"));
				dto.setPend(mr.getParameter("pend"));
				dto.setPtag1(mr.getParameter("ptag1"));
				dto.setPtag2(mr.getParameter("ptag2"));
				dto.setPtag3(mr.getParameter("ptag3"));
				dto.setPgoal(Integer.parseInt(mr.getParameter("pgoal")));
				dto.setPcount(Integer.parseInt(mr.getParameter("pcount")));
				dto.setPprice(Integer.parseInt(mr.getParameter("pprice")));
				dto.setPdetail(mr.getFilesystemName("pdetail"));
				
				dto.setSnum(maxsNum + 1);
				
				dto.setCid(cid);
				
				dao.insertProduct(dto);
				
				dao.insertMysale(dto);
				
			}
		
		url = cp+ "/funple/list.do";
		resp.sendRedirect(url);
			
		}
		
//---------------------------create-----------------------------------

		
//---------------------------delete-----------------------------------


		else if(uri.indexOf("delete.do")!=-1) {
			
			int pnum = Integer.parseInt(req.getParameter("num"));
			
			String pageNum = req.getParameter("pageNum");
			
			fundTestDTO dto = dao.getReadDataProduct(pnum);

			
			//�������� ���� ����
			FileManager.DofileDelete(dto.getPimage1(), path);
			FileManager.DofileDelete(dto.getPimage2(), path);
			FileManager.DofileDelete(dto.getPimage3(), path);
			FileManager.DofileDelete(dto.getPimage4(), path);
			FileManager.DofileDelete(dto.getPdetail(), path);
			
			//DB������ ����
			dao.deleteDataProduct(pnum);
			
			url = cp + "/funple/list.do?pageNum=" + pageNum;
			resp.sendRedirect(url);
			
		}else if(uri.indexOf("deletecart.do")!=-1) {
				
			int pnum = Integer.parseInt(req.getParameter("num"));
			
			//DB������ ����
			dao.deleteDataMycart(pnum);
			
			url = cp + "/funple/cart.do";
			resp.sendRedirect(url);

//---------------------------delete-----------------------------------

			
//---------------------------login-----------------------------------

			
		}else if(uri.indexOf("login.do")!=-1) {
			
			url = "/fund/login.jsp";
			forward(req, resp, url);
			
		}else if(uri.indexOf("login_ok.do")!=-1) {
			
			String cid = req.getParameter("cid");
			String cpwd = req.getParameter("cpwd");
			
			fundTestDTO dto = dao.getCustomData(cid);
			
			if(dto==null||(!dto.getCpwd().equals(cpwd))) {
				
				req.setAttribute("customMessage", "���̵� Ȥ�� ��й�ȣ�� <br/> ��Ȯ�� �Է����ּ���.");
				url = "/fund/login.jsp";
				forward(req, resp, url);
				return;
					
			}
			
			HttpSession session = req.getSession();
			
			dto.setCid(dto.getCid());
			dto.setCname(dto.getCname());
			
			session.setAttribute("dto", dto);
			session.setAttribute("cid", dto.getCid());
			
			String prevPage = (String) session.getAttribute("prevPage");

			if (prevPage != null && !prevPage.isEmpty()) {
			    // ���� ������ URL�� �ִٸ� �ش� �������� �����̷�Ʈ
			    resp.sendRedirect(prevPage);
			} else {
			    // ���� ������ URL�� ������ �⺻���� �����̷�Ʈ ���� ����
			    url = cp + "/funple/list.do";
			    resp.sendRedirect(url);
			}
			
//---------------------------login-----------------------------------

//---------------------------searchId-----------------------------------
			
			
		}else if(uri.indexOf("searchId.do")!=-1) {
			
			url = "/fund/searchId.jsp";
			forward(req, resp, url);
			
		}else if(uri.indexOf("searchId_ok.do")!=-1) {
			
			String cname = req.getParameter("cname");
			String ctel = req.getParameter("ctel");
			String cphone = req.getParameter("cphone");
			
			fundTestDTO dto = dao.searchCustomData(cname, ctel, cphone);
			
			if(dto==null||!dto.getCname().equals(cname)) {
				
				req.setAttribute("message", "��ġ�ϴ� ������ �����ϴ�.  <br/>  ������ �ٽ� Ȯ�����ּ���");
				url = "/fund/searchId.jsp";
				forward(req, resp, url);
				return;
				
			}else if((dto.getCname().equals(cname)) && (!dto.getCtel().equals(ctel))) {
				
				req.setAttribute("message", "��ġ�ϴ� ������ �����ϴ�.  <br/>  ������ �ٽ� Ȯ�����ּ���");
				url = "/fund/searchId.jsp";
				forward(req, resp, url);
				return;
				
				
			}else if((dto.getCname().equals(cname)) && (dto.getCtel().equals(ctel))&&(!dto.getCphone().equals(cphone))) {
				
				req.setAttribute("message", "��ġ�ϴ� ������ �����ϴ�.  <br/>  ������ �ٽ� Ȯ�����ּ���.");
				url = "/fund/searchId.jsp";
				forward(req, resp, url);
				return;
				
			}
				
				req.setAttribute("message", "���̵�� [" + dto.getCid() + "] �Դϴ�");
				url = "/fund/login.jsp";
				forward(req, resp, url);  
					
//---------------------------searchId-----------------------------------
					
//---------------------------searchPwd-----------------------------------
					
		}else if(uri.indexOf("searchPwd.do")!=-1) {
			
			url = "/fund/searchPwd.jsp";
			forward(req, resp, url);
			
			
			
		}else if(uri.indexOf("searchPwd_ok.do")!=-1) {
			
			String cid = req.getParameter("cid");
			String cname = req.getParameter("cname");
			String ctel = req.getParameter("ctel");
			String cphone = req.getParameter("cphone");
			
			fundTestDTO dto = dao.searchCustomPassword(cid, cname, ctel, cphone);
		
			if(dto==null||!dto.getCid().equals(cid)) {
				
				req.setAttribute("message", "��ġ�ϴ� ������ �����ϴ�. ������ Ȯ�����ּ��� ");
				url = "/fund/searchPwd.jsp";
				forward(req, resp, url);
				return;
			
			
			}else if(dto==null||!dto.getCname().equals(cname)) {
				
				req.setAttribute("message", "��ġ�ϴ� ������ �����ϴ�. ������ Ȯ�����ּ���");
				url = "/fund/searchPwd.jsp";
				forward(req, resp, url);
				return;
				
			}else if((dto.getCname().equals(cname)) && (!dto.getCtel().equals(ctel))) {
				
				req.setAttribute("message", "��ġ�ϴ� ������ �����ϴ�. ������ Ȯ�����ּ���");
				url = "/fund/searchPwd.jsp";
				forward(req, resp, url);
				return;
				
				
			}else if((dto.getCname().equals(cname)) && (dto.getCtel().equals(ctel))&&(!dto.getCphone().equals(cphone))) {
				
				req.setAttribute("message", " ��ġ�ϴ� ������ �����ϴ�. ������ Ȯ�����ּ��� .");
				url = "/fund/searchPwd.jsp";
				forward(req, resp, url);
				return;
				
			}
				
				req.setAttribute("message", dto.getCname() + "����  <br/> ��й�ȣ��  [" + dto.getCpwd() + "] �Դϴ�");
				url = "/fund/login.jsp";
				forward(req, resp, url);  		
			
//---------------------------searchPwd-----------------------------------

//---------------------------logout-----------------------------------

			
		}else if(uri.indexOf("logout.do")!=-1) {
			
			HttpSession session = req.getSession();

			  session.removeAttribute("dto");
			  session.invalidate();
			
			
			    url = cp + "/funple/list.do";
			    resp.sendRedirect(url);

//---------------------------logout-----------------------------------
			    
//---------------------------join-----------------------------------
			    
			}else if(uri.indexOf("join.do")!=-1) {
				
				url = "/fund/join.jsp";
				forward(req, resp, url);  	
				
				
			}else if(uri.indexOf("join_ok.do")!=-1) {
				
				fundTestDTO dto = new fundTestDTO();
				
				dto.setCid(req.getParameter("cid"));
				dto.setCpwd(req.getParameter("cpwd"));
				dto.setCname(req.getParameter("cname"));
				dto.setCemail(req.getParameter("cemail"));
				dto.setCbirth(req.getParameter("cbirth"));
				dto.setCtel(req.getParameter("ctel"));
				dto.setCphone(req.getParameter("cphone"));
				dto.setCaccount(req.getParameter("caccount"));
				dto.setCcard(req.getParameter("ccard"));
				dto.setCaddress(req.getParameter("caddress"));
				
				dao.insertCustomer(dto);
				
				url = cp+ "/funple/login.do";
				  resp.sendRedirect(url);
				
				
			
//---------------------------join-----------------------------------
				  
//--------------------------update----------------------------------------
				  

			} else if(uri.indexOf("update.do") != -1) {
				
			    HttpSession session = req.getSession();
			    fundTestDTO dto = (fundTestDTO) session.getAttribute("dto");

			    if(dto == null) {

			        url = cp + "/funple/login.do";
			        resp.sendRedirect(url);
			    } 

			        req.setAttribute("dto", dto);
			        url = "/fund/update.jsp";
			        forward(req, resp, url);
			
			        
			}else if(uri.indexOf("update_myInfo.do")!=-1) {
				
				url = "/fund/update_myInfo.jsp";
				forward(req, resp, url);  	
				
			
			}else if(uri.indexOf("update_myInfo.do")!=-1) { 
				
			    fundTestDTO dto = new fundTestDTO();
			    
			    dto.setCpwd(req.getParameter("cpwd"));
			    dto.setCemail(req.getParameter("cemail"));
			    dto.setCtel(req.getParameter("ctel"));
			    dto.setCphone(req.getParameter("cphone"));
			    dto.setCaccount(req.getParameter("caccount"));
			    dto.setCcard(req.getParameter("ccard"));
			    dto.setCaddress(req.getParameter("caddress"));
			    dto.setCid(req.getParameter("cid"));
			    
			    dao.updateData(dto);
			    
			    url = cp + "/funple/update_myInfo.do";
			    resp.sendRedirect(url);
			    
//--------------------------update----------------------------------------
			    
//--------------------------update_myOrder----------------------------------------
			}
			else if(uri.indexOf("update_myOrder.do")!=-1) {
				
				HttpSession session = req.getSession();
				
				String cid = (String)session.getAttribute("cid");

				List<fundTestDTO> lists = dao.getListMyorder(cid);

				String deletePath = cp + "/funple/deletecart.do";
				String downloadPath = cp + "/funple/download.do";

				String imagePath = cp + "/pds/imageFile";
				req.setAttribute("imagePath", imagePath);

				req.setAttribute("downloadPath", downloadPath);
				req.setAttribute("deletePath", deletePath);
				
				req.setAttribute("lists", lists);
				
				url = "/fund/update_myOrder.jsp";
				forward(req, resp, url);  	
				
			
			}
			else if(uri.indexOf("update_myOrder_ok.do")!=-1) { 
				
				String cid = req.getParameter("cid");
				
				fundTestDTO dto = dao.getCustomData(cid);
				
				if(dto==null) {
					
					req.setAttribute("dto", dto);
					url = "/fund/update.jsp";
					forward(req, resp, url);
					return;
						
				}
				
				HttpSession session = req.getSession();
				
				dto.setCid(dto.getCid());
				dto.setCname(dto.getCname());
				
				session.setAttribute("dto", dto);
				session.setAttribute("cid", dto.getCid());
				
				url = cp + "/funple/update_myOrder.do";
		    	resp.sendRedirect(url);
   
			}
		    	
//--------------------------update_myOrder----------------------------------------
			
//--------------------------mysale----------------------------------------
		    	
		    	
			
			else if(uri.indexOf("mysale.do")!=-1) {
				
				//������ ��ȣ ó��
				String pageNum = req.getParameter("pageNum");
				int currentPage = 1;

				if (pageNum != null) {
				    currentPage = Integer.parseInt(pageNum);
				}

				//���������� ���� ���� ��ġ�����ϱ�?
				String searchValue = req.getParameter("searchValue");

				//���ڵ� �κ�
				if (searchValue != null) {
				    if (req.getMethod().equalsIgnoreCase("GET")) {
				        searchValue = URLDecoder.decode(searchValue, "UTF-8");
				    }
				} else {
				    searchValue = "";
				}
				

				//������ ������ �������� �����
				int dataCount = dao.getDataCountMysale();

				int row = 4;
				int column = 2;
				int numPerPage = row * column;
				int totalPage = myUtil.getPageCount(numPerPage, dataCount);
				
				//������ ���� ó��
				if (currentPage > totalPage) {
				    currentPage = totalPage;
				}

				int start = (currentPage - 1) * numPerPage + 1;
				int end = currentPage * numPerPage;
				
				HttpSession session = req.getSession();
				
				String cid = (String)session.getAttribute("cid");
				
				List<fundTestDTO> lists = dao.getListMysale(start, end, cid);
				
				//����¡ ó��
				String param = "";

				if (searchValue != null && !searchValue.equals("")) {
				    param = "&searchValue=" + URLDecoder.decode(searchValue, "UTF-8");
				}

				String urlList = cp + "/funple/list.do";

				if (!param.equals("")) {
				    urlList += "?" + param;
				}

				String pageIndexList = myUtil.pageIndexList(currentPage, totalPage, urlList);

				//�̿��� �ø�
				String articleUrl = cp + "/funple/detail.do?pageNum=" + currentPage;

				if (!param.equals("")) {
				    articleUrl += "&" + param;
				}

				String deletePath = cp + "/funple/delete.do";
				String downloadPath = cp + "/funple/download.do";
				
				String imagePath = cp + "/pds/imageFile";
				req.setAttribute("imagePath", imagePath);

				req.setAttribute("downloadPath", downloadPath);
				req.setAttribute("deletePath", deletePath);
				req.setAttribute("lists", lists);
				req.setAttribute("pageIndexList", pageIndexList);
				req.setAttribute("dataCount", dataCount);
				req.setAttribute("pageNum", currentPage);
				req.setAttribute("pageMax", totalPage);
				req.setAttribute("listsSize", lists.size());
				req.setAttribute("row", row);
				req.setAttribute("column", column);
				req.setAttribute("articleUrl", articleUrl);

				
				
				
				
				url = "/fund/mysale.jsp";
				forward(req, resp, url);
				
			}
//--------------------------mysale----------------------------------------

//--------------------------cart----------------------------------------
				
			else if(uri.indexOf("cart.do")!=-1) {
				

				//������ ������ �������� �����
				int dataCount = dao.getDataCountMysale();
				
				
				HttpSession session = req.getSession();
				
				String cid = (String)session.getAttribute("cid");

				List<fundTestDTO> lists1 = dao.getListMycart1(1,1,cid);
				List<fundTestDTO> lists2 = dao.getListMycart2(2,2,cid);
				List<fundTestDTO> lists3 = dao.getListMycart3(3,3,cid);
				List<fundTestDTO> lists4 = dao.getListMycart4(4,4,cid);
				List<fundTestDTO> lists5 = dao.getListMycart5(5,5,cid);

				String deletePath = cp + "/funple/deletecart.do";
				String downloadPath = cp + "/funple/download.do";

				String imagePath = cp + "/pds/imageFile";
				req.setAttribute("imagePath", imagePath);

				req.setAttribute("downloadPath", downloadPath);
				req.setAttribute("deletePath", deletePath);
				
				req.setAttribute("lists1", lists1);
				req.setAttribute("listsSize1", lists1.size());
				req.setAttribute("lists2", lists2);
				req.setAttribute("listsSize2", lists2.size());
				req.setAttribute("lists3", lists3);
				req.setAttribute("listsSize3", lists3.size());
				req.setAttribute("lists4", lists4);
				req.setAttribute("listsSize4", lists4.size());
				req.setAttribute("lists5", lists5);
				req.setAttribute("listsSize5", lists5.size());

				req.setAttribute("dataCount", dataCount);


				
				url = "/fund/cart.jsp";
				forward(req, resp, url);
				
			}else if(uri.indexOf("cart_ok.do")!=-1) {
			
				String cid = req.getParameter("cid");
		
				//�α��� ���� Ȯ��
				if(cid==null || cid.equals("")) {
					req.setAttribute("message", "�α����� �ʿ��մϴ�.");
					url = "/funple/login.do";
					forward(req, resp, url);
					return;
				}
				
				fundTestDTO dto = new fundTestDTO();
				
				int maxoNum = dao.getMaxNumMyorder();
				
				fundTestDTO cdto = dao.getCustomData(cid);
				
				dto.setOnum(maxoNum + 1);
				dto.setPnum(Integer.parseInt(req.getParameter("pnum")));
				dto.setCid(cid);
				dto.setPproname(req.getParameter("pproname"));
				dto.setPprice(Integer.parseInt(req.getParameter("pprice")));
				dto.setPimage1(req.getParameter("pimage1"));
				dto.setOamount(Integer.parseInt(req.getParameter("oamount")));
				dto.setCaddress(cdto.getCaddress());
				dto.setOdelivery(3000);
				
				dao.insertMyorder(dto);
				dao.updateProduct(dto);
				dao.updateMysale(dto);
				
				int pnum = Integer.parseInt(req.getParameter("pnum"));
				
				//DB������ ����
				dao.deleteDataMycart(pnum);
				
				url = cp + "/funple/cart.do";
				resp.sendRedirect(url);
			}
				
//--------------------------cart----------------------------------------
			else if(uri.indexOf("helpCenter.do")!=-1) {
				
				url = "/fund/helpCenter.jsp";
				forward(req, resp, url);
				
			}else if(uri.indexOf("helpCenter_ok.do")!=-1) {
				
		
				 HttpSession session = req.getSession();
			    fundTestDTO dto = (fundTestDTO) session.getAttribute("dto");
				
				
				dto.setCid(dto.getCid());
				dto.setCname(dto.getCname());
				
				session.setAttribute("dto", dto);
				session.setAttribute("cid", dto.getCid());
				
				String prevPage = (String) session.getAttribute("prevPage");
		
				if (prevPage != null && !prevPage.isEmpty()) {
				    // ���� ������ URL�� �ִٸ� �ش� �������� �����̷�Ʈ
				    resp.sendRedirect(prevPage);
				} else {
				    // ���� ������ URL�� ������ �⺻���� �����̷�Ʈ ���� ����
				    url = cp + "/funple/list.do";
				    resp.sendRedirect(url);
				}
		}
	}
}